import { useState, useEffect } from 'react';
import AssetCard from '../../components/AssetCard';
import AssetModal from '../../components/AssetModal';
import CreateAssetModal from "../../components/CreateAssetModal";
import axios from 'axios';
import kpiData from "../../models/kpi_data";

export default function LibraryPage() {
  const [assets, setAssets] = useState<any[]>([]);
  const [trendAssets, setTrendAssets] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAsset, setSelectedAsset] = useState<any>(null);
  const [selectedKPI, setSelectedKPI] = useState<any>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("Featured");

  useEffect(() => {
    fetchAssets();
    fetchTrendAssets();
  }, [searchQuery]);

  const fetchAssets = async () => {
    try {
      const res = await axios.get(`/api/assets?search=${searchQuery}`);
      setAssets(res.data);
    } catch (error) {
      console.error('Error fetching assets:', error);
    }
  };

  const fetchTrendAssets = async () => {
    try {
      const res = await axios.get(`/api/assets?search=`);
      setTrendAssets(res.data);
    } catch (error) {
      console.error('Error fetching assets:', error);
    }
  };

  const handleAssetClick = (asset: any) => {
    setSelectedAsset(asset._id === selectedAsset?._id ? null : asset);
  };

  const handleTabClick = (tab: string) => {
    setActiveTab(tab);
    if (tab === "KPI" && selectedAsset) {
      fetchKPIData(selectedAsset.name);
    }
  };

  const fetchKPIData = (assetName: string) => {
    if (kpiData[assetName]) {
      setSelectedKPI(kpiData[assetName]);
    } else {
      setSelectedKPI([]);
    }
  };

  return (
    <div className="max-w-5xl px-48 mx-auto bg-gray-200 p-6 rounded-lg shadow-md">
      <div className="absolute top-6 right-96 px-24 flex gap-4">
        <button onClick={() => setIsCreateModalOpen(true)} className="bg-gray-800 text-white px-4 py-2 rounded-md hover:bg-gray-700 transition">Create</button>
        <button onClick={() => setIsCreateModalOpen(true)} className="bg-gray-800 text-white px-4 py-2 rounded-md hover:bg-gray-700 transition">Request</button>
      </div>

      <h1 className="text-5xl text-center font-bold mb-8">Library</h1>
      <input type="text" className="w-full border rounded p-2 mb-4" placeholder="Type to search..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />

      <div className="flex bg-gray-100 p-2 rounded-lg mb-4">
        {["Featured", "KPI", "Data Viz", "Layout", "Storyboard"].map((tab) => (
          <button key={tab} className={`w-full px-6 py-2 text-sm font-medium rounded-md ${activeTab === tab ? "bg-white shadow text-gray-900" : "text-gray-500 hover:text-gray-700"}`} onClick={() => handleTabClick(tab)}>{tab}</button>
        ))}
      </div>

      {activeTab === "KPI" && selectedKPI ? (
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-xl font-bold">KPI Details</h2>
          {selectedKPI.map((kpi: any) => (
            <div key={kpi.id} className="mb-4 border p-3 rounded-lg">
              <h3 className="text-lg font-semibold">{kpi.name}</h3>
              <p>{kpi.description}</p>
              <p><strong>Metric ID:</strong> {kpi.metricID}</p>
              <p><strong>Calculation:</strong> {kpi.calculation}</p>
              <p><strong>Visuals:</strong> {kpi.visualsAvailable.join(", ")}</p>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-4">
          {assets.map((asset) => (
            <AssetCard key={asset._id} asset={asset} onClick={() => handleAssetClick(asset)} isSelected={selectedAsset && selectedAsset._id === asset._id} />
          ))}
        </div>
      )}

      {isCreateModalOpen && <CreateAssetModal onClose={() => setIsCreateModalOpen(false)} refreshAssets={fetchAssets} />}
    </div>
  );
}
